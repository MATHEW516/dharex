// src/app/api/admin/prices/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient, createAdminSupabaseClient } from '@/lib/supabase/server'

// GET: fetch all price overrides
export async function GET() {
  const supabase = createAdminSupabaseClient()
  const { data, error } = await supabase.from('price_overrides').select('*')
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

// POST: set or clear a price override
export async function POST(req: NextRequest) {
  const authClient = createServerSupabaseClient()
  const { data: { user } } = await authClient.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const adminClient = createAdminSupabaseClient()
  const { data: profile } = await adminClient
    .from('profiles').select('role').eq('id', user.id).single()
  if (profile?.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { asset, price, is_overridden } = await req.json()
  if (!['BTC', 'ETH', 'SOL'].includes(asset)) {
    return NextResponse.json({ error: 'Invalid asset' }, { status: 400 })
  }

  const { error } = await adminClient
    .from('price_overrides')
    .update({
      override_price: price,
      is_overridden: is_overridden ?? true,
      updated_by: user.id,
      updated_at: new Date().toISOString(),
    })
    .eq('asset', asset)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true })
}
