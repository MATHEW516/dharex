// src/app/api/admin/transactions/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient, createAdminSupabaseClient } from '@/lib/supabase/server'

// GET: all transactions with user info
export async function GET(req: NextRequest) {
  const authClient = createServerSupabaseClient()
  const { data: { user } } = await authClient.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const adminClient = createAdminSupabaseClient()
  const { data: profile } = await adminClient
    .from('profiles').select('role').eq('id', user.id).single()
  if (profile?.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const url = new URL(req.url)
  const status = url.searchParams.get('status')

  let query = adminClient
    .from('transactions')
    .select(`*, profiles:user_id (full_name, email)`)
    .order('created_at', { ascending: false })
    .limit(200)

  if (status) query = query.eq('status', status)

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

// PATCH: approve or reject a transaction
export async function PATCH(req: NextRequest) {
  const authClient = createServerSupabaseClient()
  const { data: { user } } = await authClient.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const adminClient = createAdminSupabaseClient()
  const { data: profile } = await adminClient
    .from('profiles').select('role').eq('id', user.id).single()
  if (profile?.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { transaction_id, action, admin_note } = await req.json()
  if (!['approve', 'reject'].includes(action)) {
    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  }

  if (action === 'approve') {
    // Get transaction to check type
    const { data: tx } = await adminClient
      .from('transactions').select('*').eq('id', transaction_id).single()
    if (!tx) return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    if (tx.status !== 'pending') return NextResponse.json({ error: 'Not pending' }, { status: 400 })

    if (tx.type === 'deposit') {
      // Atomically credit user balance
      const { error } = await adminClient.rpc('approve_deposit', {
        tx_id: transaction_id,
        admin_id: user.id,
      })
      if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    } else if (tx.type === 'withdrawal') {
      const { error } = await adminClient.rpc('approve_withdrawal', {
        tx_id: transaction_id,
        admin_id: user.id,
      })
      if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    } else {
      await adminClient.from('transactions').update({
        status: 'approved',
        reviewed_by: user.id,
        reviewed_at: new Date().toISOString(),
        admin_note,
      }).eq('id', transaction_id)
    }
  } else {
    // Reject
    await adminClient.from('transactions').update({
      status: 'rejected',
      reviewed_by: user.id,
      reviewed_at: new Date().toISOString(),
      admin_note,
    }).eq('id', transaction_id)
  }

  return NextResponse.json({ success: true })
}
