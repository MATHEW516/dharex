// src/app/api/prices/route.ts
import { NextResponse } from 'next/server'
import { createAdminSupabaseClient } from '@/lib/supabase/server'

let cache: { prices: any; ts: number } | null = null
const CACHE_TTL = 15_000 // 15 seconds

export async function GET() {
  try {
    // Return cached prices if fresh
    if (cache && Date.now() - cache.ts < CACHE_TTL) {
      return NextResponse.json(cache.prices)
    }

    // Fetch live prices from CoinGecko (free, no key needed)
    const url = 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd&include_24hr_change=true'
    const headers: Record<string, string> = { 'Accept': 'application/json' }
    if (process.env.COINGECKO_API_KEY) {
      headers['x-cg-demo-api-key'] = process.env.COINGECKO_API_KEY
    }

    const res = await fetch(url, { headers, next: { revalidate: 15 } })
    const data = await res.json()

    let prices = {
      BTC: { price: data.bitcoin?.usd ?? 67000, change24h: data.bitcoin?.usd_24h_change ?? 0 },
      ETH: { price: data.ethereum?.usd ?? 3500, change24h: data.ethereum?.usd_24h_change ?? 0 },
      SOL: { price: data.solana?.usd ?? 150, change24h: data.solana?.usd_24h_change ?? 0 },
    }

    // Check for admin SOL price override in Supabase
    const supabase = createAdminSupabaseClient()
    const { data: overrides } = await supabase
      .from('price_overrides')
      .select('*')
      .eq('is_overridden', true)

    if (overrides) {
      for (const override of overrides) {
        if (override.asset === 'SOL' && override.override_price) {
          prices.SOL.price = override.override_price
        }
        if (override.asset === 'BTC' && override.override_price) {
          prices.BTC.price = override.override_price
        }
        if (override.asset === 'ETH' && override.override_price) {
          prices.ETH.price = override.override_price
        }
      }
    }

    cache = { prices, ts: Date.now() }
    return NextResponse.json(prices)
  } catch (err) {
    console.error('Price fetch error:', err)
    // Fallback prices if API fails
    return NextResponse.json({
      BTC: { price: 67000, change24h: 0 },
      ETH: { price: 3500, change24h: 0 },
      SOL: { price: 150, change24h: 0 },
    })
  }
}
