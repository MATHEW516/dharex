// src/app/api/transactions/trade/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient, createAdminSupabaseClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const authClient = createServerSupabaseClient()
  const { data: { user } } = await authClient.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { type, asset, usd_amount } = await req.json() // type: 'buy' | 'sell'
  if (!['buy', 'sell'].includes(type)) return NextResponse.json({ error: 'Invalid type' }, { status: 400 })
  if (!['BTC', 'ETH', 'SOL'].includes(asset)) return NextResponse.json({ error: 'Invalid asset' }, { status: 400 })
  if (!usd_amount || usd_amount <= 0) return NextResponse.json({ error: 'Invalid amount' }, { status: 400 })

  // Get live price
  const priceRes = await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/prices`)
  const prices = await priceRes.json()
  const price = prices[asset]?.price
  if (!price) return NextResponse.json({ error: 'Price unavailable' }, { status: 500 })

  const crypto_amount = usd_amount / price
  const balKey = asset.toLowerCase() + '_balance' // btc_balance, eth_balance, sol_balance

  const adminClient = createAdminSupabaseClient()

  // Fetch current user profile
  const { data: profile, error: profileErr } = await adminClient
    .from('profiles').select('*').eq('id', user.id).single()
  if (profileErr || !profile) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  if (type === 'buy') {
    if (profile.usd_balance < usd_amount) {
      return NextResponse.json({ error: 'Insufficient USD balance' }, { status: 400 })
    }
    const { error } = await adminClient.from('profiles').update({
      usd_balance: profile.usd_balance - usd_amount,
      [balKey]: (profile[balKey] || 0) + crypto_amount,
    }).eq('id', user.id)
    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  } else {
    if ((profile[balKey] || 0) < crypto_amount) {
      return NextResponse.json({ error: `Insufficient ${asset} balance` }, { status: 400 })
    }
    const { error } = await adminClient.from('profiles').update({
      usd_balance: profile.usd_balance + usd_amount,
      [balKey]: (profile[balKey] || 0) - crypto_amount,
    }).eq('id', user.id)
    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  }

  // Record transaction
  await adminClient.from('transactions').insert({
    user_id: user.id,
    type,
    asset,
    usd_amount,
    crypto_amount,
    price_at_time: price,
    payment_method: 'trade',
    status: 'completed',
  })

  return NextResponse.json({ success: true, crypto_amount, price_at_time: price })
}
