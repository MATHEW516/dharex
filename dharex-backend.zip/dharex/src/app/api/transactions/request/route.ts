// src/app/api/transactions/request/route.ts
// Handles manual deposit requests (bank transfer, crypto) and all withdrawals
import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient, createAdminSupabaseClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const authClient = createServerSupabaseClient()
  const { data: { user } } = await authClient.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { type, usd_amount, payment_method, payment_reference } = await req.json()
  if (!['deposit', 'withdrawal'].includes(type)) {
    return NextResponse.json({ error: 'Invalid type' }, { status: 400 })
  }
  if (!usd_amount || usd_amount <= 0) {
    return NextResponse.json({ error: 'Invalid amount' }, { status: 400 })
  }

  const adminClient = createAdminSupabaseClient()

  // For withdrawals: verify user has enough balance
  if (type === 'withdrawal') {
    const { data: profile } = await adminClient
      .from('profiles').select('usd_balance').eq('id', user.id).single()
    if (!profile || profile.usd_balance < usd_amount) {
      return NextResponse.json({ error: 'Insufficient balance' }, { status: 400 })
    }
  }

  const { data, error } = await adminClient.from('transactions').insert({
    user_id: user.id,
    type,
    asset: 'USD',
    usd_amount,
    payment_method: payment_method || 'bank',
    status: 'pending',
    payment_reference: payment_reference || null,
  }).select().single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true, transaction: data })
}

// GET: user's own transaction history
export async function GET(req: NextRequest) {
  const authClient = createServerSupabaseClient()
  const { data: { user } } = await authClient.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const adminClient = createAdminSupabaseClient()
  const { data, error } = await adminClient
    .from('transactions')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(100)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}
