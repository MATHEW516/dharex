// src/app/api/payments/paypal/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient, createAdminSupabaseClient } from '@/lib/supabase/server'

const PAYPAL_BASE = process.env.PAYPAL_BASE_URL || 'https://api-m.paypal.com'

async function getPayPalToken(): Promise<string> {
  const auth = Buffer.from(
    `${process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
  ).toString('base64')

  const res = await fetch(`${PAYPAL_BASE}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  })
  const data = await res.json()
  return data.access_token
}

// POST: Create PayPal order
export async function POST(req: NextRequest) {
  const authClient = createServerSupabaseClient()
  const { data: { user } } = await authClient.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { amount } = await req.json()
  if (!amount || amount < 10) return NextResponse.json({ error: 'Minimum deposit is $10' }, { status: 400 })

  try {
    const token = await getPayPalToken()
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

    const res = await fetch(`${PAYPAL_BASE}/v2/checkout/orders`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        intent: 'CAPTURE',
        purchase_units: [{
          amount: { currency_code: 'USD', value: amount.toFixed(2) },
          description: `Dharex Deposit - $${amount}`,
        }],
        application_context: {
          return_url: `${appUrl}/wallet?paypal=success`,
          cancel_url: `${appUrl}/wallet?paypal=cancel`,
        },
      }),
    })
    const order = await res.json()

    // Create pending transaction
    const adminClient = createAdminSupabaseClient()
    await adminClient.from('transactions').insert({
      user_id: user.id,
      type: 'deposit',
      asset: 'USD',
      usd_amount: amount,
      payment_method: 'paypal',
      status: 'pending',
      payment_reference: order.id,
    })

    const approvalUrl = order.links?.find((l: any) => l.rel === 'approve')?.href
    return NextResponse.json({ order_id: order.id, approval_url: approvalUrl })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

// PATCH: Capture PayPal order after user approves
export async function PATCH(req: NextRequest) {
  const authClient = createServerSupabaseClient()
  const { data: { user } } = await authClient.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { order_id } = await req.json()

  try {
    const token = await getPayPalToken()
    const res = await fetch(`${PAYPAL_BASE}/v2/checkout/orders/${order_id}/capture`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    })
    const capture = await res.json()

    if (capture.status === 'COMPLETED') {
      const adminClient = createAdminSupabaseClient()
      const { data: tx } = await adminClient
        .from('transactions')
        .select('*')
        .eq('payment_reference', order_id)
        .single()

      if (tx) {
        await adminClient.rpc('approve_deposit', { tx_id: tx.id, admin_id: user.id })
      }
      return NextResponse.json({ success: true })
    }
    return NextResponse.json({ error: 'Payment not completed' }, { status: 400 })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
