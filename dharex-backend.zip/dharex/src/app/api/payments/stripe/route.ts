// src/app/api/payments/stripe/route.ts
import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createServerSupabaseClient, createAdminSupabaseClient } from '@/lib/supabase/server'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' })

// POST: Create Stripe Payment Intent for deposit
export async function POST(req: NextRequest) {
  const authClient = createServerSupabaseClient()
  const { data: { user } } = await authClient.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { amount } = await req.json() // amount in USD
  if (!amount || amount < 10) return NextResponse.json({ error: 'Minimum deposit is $10' }, { status: 400 })

  const amountCents = Math.round(amount * 100) // Stripe uses cents

  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountCents,
      currency: 'usd',
      metadata: { user_id: user.id, type: 'deposit' },
      automatic_payment_methods: { enabled: true },
    })

    // Create a pending transaction record
    const adminClient = createAdminSupabaseClient()
    await adminClient.from('transactions').insert({
      user_id: user.id,
      type: 'deposit',
      asset: 'USD',
      usd_amount: amount,
      payment_method: 'card',
      status: 'pending',
      payment_reference: paymentIntent.id,
    })

    return NextResponse.json({ client_secret: paymentIntent.client_secret })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
