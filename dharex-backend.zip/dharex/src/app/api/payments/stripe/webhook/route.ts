// src/app/api/payments/stripe/webhook/route.ts
import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createAdminSupabaseClient } from '@/lib/supabase/server'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' })

export async function POST(req: NextRequest) {
  const body = await req.text()
  const sig = req.headers.get('stripe-signature')!

  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err: any) {
    console.error('Webhook signature failed:', err.message)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  if (event.type === 'payment_intent.succeeded') {
    const intent = event.data.object as Stripe.PaymentIntent
    const userId = intent.metadata.user_id
    const amount = intent.amount / 100 // convert cents to dollars

    const adminClient = createAdminSupabaseClient()

    // Find the pending transaction by payment reference
    const { data: tx } = await adminClient
      .from('transactions')
      .select('*')
      .eq('payment_reference', intent.id)
      .eq('status', 'pending')
      .single()

    if (tx) {
      // Auto-approve card deposits since Stripe confirmed payment
      await adminClient.rpc('approve_deposit', {
        tx_id: tx.id,
        admin_id: userId, // self-approved via Stripe
      })
      console.log(`Auto-approved card deposit ${intent.id} for user ${userId}: $${amount}`)
    }
  }

  if (event.type === 'payment_intent.payment_failed') {
    const intent = event.data.object as Stripe.PaymentIntent
    const adminClient = createAdminSupabaseClient()
    await adminClient
      .from('transactions')
      .update({ status: 'rejected', admin_note: 'Payment failed via Stripe' })
      .eq('payment_reference', intent.id)
  }

  return NextResponse.json({ received: true })
}

// Stripe requires raw body - disable Next.js body parsing
export const config = { api: { bodyParser: false } }
