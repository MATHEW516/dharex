// src/lib/supabase/client.ts
// Browser-side Supabase client (use in components)
import { createBrowserClient } from '@supabase/ssr'

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}

// ─── Types ────────────────────────────────────────────────
export type Profile = {
  id: string
  email: string
  full_name: string
  role: 'user' | 'admin'
  usd_balance: number
  btc_balance: number
  eth_balance: number
  sol_balance: number
  is_verified: boolean
  is_suspended: boolean
  created_at: string
}

export type Transaction = {
  id: string
  user_id: string
  type: 'deposit' | 'withdrawal' | 'buy' | 'sell'
  asset: string
  usd_amount: number | null
  crypto_amount: number | null
  price_at_time: number | null
  payment_method: 'bank' | 'card' | 'crypto' | 'paypal' | 'trade' | null
  status: 'pending' | 'approved' | 'rejected' | 'completed'
  admin_note: string | null
  payment_reference: string | null
  created_at: string
  profiles?: Pick<Profile, 'full_name' | 'email'>
}

export type PriceOverride = {
  asset: string
  override_price: number | null
  is_overridden: boolean
  updated_at: string
}

export type WalletAddress = {
  id: string
  asset: string
  address: string
  network: string
}

export type LivePrices = {
  BTC: number
  ETH: number
  SOL: number
}
