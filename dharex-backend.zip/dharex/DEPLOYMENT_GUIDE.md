# 🚀 DHAREX — Complete Deployment Guide
## Supabase + Vercel + Stripe + PayPal

---

## OVERVIEW

This guide gets your Dharex platform live in ~45 minutes.

**Stack:**
- **Frontend + API:** Next.js 14 → deployed on Vercel (free)
- **Database + Auth:** Supabase (free tier: 500MB DB, 50k users)
- **Card Payments:** Stripe
- **PayPal:** PayPal Developer API
- **Live Prices:** CoinGecko API (free)

---

## STEP 1 — Set Up Supabase (15 min)

### 1.1 Create Project
1. Go to [supabase.com](https://supabase.com) → **New Project**
2. Choose organization, set project name: `dharex`
3. Set a strong database password (save it!)
4. Choose region closest to your users
5. Click **Create new project** — wait ~2 min

### 1.2 Run Database Schema
1. In Supabase dashboard → **SQL Editor**
2. Click **+ New query**
3. Open `supabase/schema.sql` from this project
4. Paste the entire contents
5. Click **Run** — you should see "Success"

### 1.3 Get Your API Keys
1. Go to **Settings → API**
2. Copy these values (you'll need them later):
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon/public key** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role key** → `SUPABASE_SERVICE_ROLE_KEY` ⚠️ Keep secret!

### 1.4 Configure Auth
1. Go to **Authentication → Providers**
2. Ensure **Email** is enabled
3. Go to **Authentication → URL Configuration**
4. Set **Site URL** to your Vercel URL (get this in Step 3, come back)
5. Add to **Redirect URLs**: `https://your-app.vercel.app/**`

### 1.5 Create Your Admin Account
1. Deploy first (Step 3), then sign up with your admin email
2. In Supabase → **Table Editor → profiles**
3. Find your row, set `role` = `admin`
4. Done — you now have admin access!

---

## STEP 2 — Set Up Payment Services

### 2.1 Stripe Setup
1. Go to [dashboard.stripe.com](https://dashboard.stripe.com) → create account
2. Go to **Developers → API Keys**
3. Copy:
   - **Publishable key** → `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
   - **Secret key** → `STRIPE_SECRET_KEY`
4. Go to **Developers → Webhooks → Add endpoint**
5. Endpoint URL: `https://your-app.vercel.app/api/payments/stripe/webhook`
6. Select events: `payment_intent.succeeded`, `payment_intent.payment_failed`
7. Copy **Signing secret** → `STRIPE_WEBHOOK_SECRET`

> ⚠️ In test mode, use `pk_test_...` and `sk_test_...` keys.
> Switch to live keys (`pk_live_...`) when ready to accept real payments.

### 2.2 PayPal Setup
1. Go to [developer.paypal.com](https://developer.paypal.com) → **My Apps & Credentials**
2. Click **Create App** → name it "Dharex"
3. Copy:
   - **Client ID** → `NEXT_PUBLIC_PAYPAL_CLIENT_ID`
   - **Secret** → `PAYPAL_CLIENT_SECRET`
4. For live payments, switch from Sandbox to Live mode
5. Set `PAYPAL_BASE_URL`:
   - Sandbox: `https://api-m.sandbox.paypal.com`
   - Live: `https://api-m.paypal.com`

### 2.3 Deposit Wallet Addresses
1. In Supabase → **Table Editor → wallet_addresses**
2. Replace the placeholder addresses with your REAL wallet addresses:
   - BTC: Your Bitcoin receiving address
   - ETH: Your Ethereum receiving address
   - SOL: Your Solana receiving address
   - USDT: Your USDT (ERC-20) receiving address
3. ⚠️ CRITICAL: Use addresses you control! Wrong address = lost funds.

---

## STEP 3 — Deploy to Vercel (10 min)

### 3.1 Push Code to GitHub
```bash
# In the dharex project folder:
git init
git add .
git commit -m "Initial Dharex platform"
git remote add origin https://github.com/yourusername/dharex.git
git push -u origin main
```

### 3.2 Connect to Vercel
1. Go to [vercel.com](https://vercel.com) → **Add New Project**
2. Import your GitHub repository
3. Framework: **Next.js** (auto-detected)
4. Click **Environment Variables** and add ALL of the following:

```
NEXT_PUBLIC_SUPABASE_URL          = https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY     = eyJ...
SUPABASE_SERVICE_ROLE_KEY         = eyJ...

NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY = pk_live_...
STRIPE_SECRET_KEY                  = sk_live_...
STRIPE_WEBHOOK_SECRET              = whsec_...

NEXT_PUBLIC_PAYPAL_CLIENT_ID       = AXxx...
PAYPAL_CLIENT_SECRET               = your_secret
PAYPAL_BASE_URL                    = https://api-m.paypal.com

NEXT_PUBLIC_APP_URL                = https://your-app.vercel.app
NEXT_PUBLIC_APP_NAME               = Dharex
```

5. Click **Deploy** — wait ~2 min
6. Copy your Vercel URL → go back to Supabase and update Auth URLs

### 3.3 Install & Run Locally (for development)
```bash
cd dharex
npm install
cp .env.example .env.local
# Fill in .env.local with your keys
npm run dev
# Open http://localhost:3000
```

---

## STEP 4 — Configure Admin

### Set SOL Price Override
1. Log in with your admin account
2. Go to **Admin Panel → Prices**
3. Toggle SOL price override ON
4. Set your desired price
5. Click Save — all users immediately see this price

### Approve Deposits & Withdrawals
1. Go to **Admin Panel → Transactions**
2. Filter by "Pending"
3. Click **Approve** or **Reject**
4. For deposits: user balance is credited automatically
5. For withdrawals: manually send funds, then approve

---

## STEP 5 — Custom Domain (Optional)

1. In Vercel → **Settings → Domains**
2. Add your domain (e.g., `dharex.com`)
3. Follow DNS instructions for your registrar
4. Update `NEXT_PUBLIC_APP_URL` in Vercel environment variables
5. Update Supabase Auth URLs with new domain
6. Redeploy

---

## PAYMENT FLOW SUMMARY

| Method | Flow | Auto-Approve? |
|--------|------|--------------|
| **Card (Stripe)** | User pays → Stripe webhook fires → auto-credited | ✅ Yes |
| **PayPal** | User pays → PayPal capture → auto-credited | ✅ Yes |
| **Bank Transfer** | User submits request → admin manually verifies → approves | ❌ Manual |
| **Crypto Deposit** | User sends to wallet → admin verifies on-chain → approves | ❌ Manual |
| **Withdrawal** | User requests → admin reviews → approves → send manually | ❌ Manual |

---

## SECURITY CHECKLIST

- [ ] Never commit `.env.local` to Git (it's in `.gitignore`)
- [ ] Keep `SUPABASE_SERVICE_ROLE_KEY` only in server-side env vars
- [ ] Use live Stripe keys only in production
- [ ] Replace all placeholder wallet addresses with real ones
- [ ] Enable 2FA on your Supabase, Vercel, and Stripe accounts
- [ ] Review Supabase Row Level Security policies
- [ ] Set up Supabase database backups (Project Settings → Backups)

---

## TROUBLESHOOTING

**"Invalid API key" errors**
→ Check `.env.local` has no extra spaces. Restart dev server after changes.

**Stripe webhook not working**
→ Make sure webhook URL is exact. Check Stripe Dashboard → Webhooks → Recent deliveries.

**User balance not updating after Stripe payment**
→ Check webhook is configured and `STRIPE_WEBHOOK_SECRET` is correct.

**Admin panel not visible**
→ Manually set `role = 'admin'` in Supabase profiles table for your user.

**CoinGecko rate limited**
→ Prices are cached for 15s. For higher limits, add a free API key at coingecko.com.

---

## SUPPORT

For questions about this codebase, check the inline comments in each file.
The project structure follows Next.js 14 App Router conventions.

**Files overview:**
```
dharex/
├── supabase/schema.sql          ← Run this in Supabase SQL Editor
├── .env.example                 ← Copy to .env.local and fill in
├── middleware.ts                ← Auth route protection
└── src/
    ├── lib/supabase/            ← DB client utilities
    └── app/api/
        ├── prices/              ← Live CoinGecko prices
        ├── admin/
        │   ├── prices/          ← Admin SOL price override
        │   └── transactions/    ← Approve/reject deposits & withdrawals
        ├── payments/
        │   ├── stripe/          ← Card payments + webhook
        │   └── paypal/          ← PayPal orders + capture
        └── transactions/
            ├── trade/           ← Buy/sell crypto
            └── request/         ← Manual deposit/withdrawal requests
```
