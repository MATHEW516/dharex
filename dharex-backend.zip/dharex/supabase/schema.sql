-- ============================================================
-- DHAREX PLATFORM - SUPABASE SCHEMA
-- Run this entire file in Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── USERS (extends Supabase auth.users) ───────────────────
CREATE TABLE public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  usd_balance NUMERIC(18,2) NOT NULL DEFAULT 0,
  btc_balance NUMERIC(18,8) NOT NULL DEFAULT 0,
  eth_balance NUMERIC(18,8) NOT NULL DEFAULT 0,
  sol_balance NUMERIC(18,8) NOT NULL DEFAULT 0,
  is_verified BOOLEAN DEFAULT FALSE,
  is_suspended BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── TRANSACTIONS ───────────────────────────────────────────
CREATE TABLE public.transactions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('deposit', 'withdrawal', 'buy', 'sell')),
  asset TEXT NOT NULL DEFAULT 'USD',
  usd_amount NUMERIC(18,2),
  crypto_amount NUMERIC(18,8),
  price_at_time NUMERIC(18,2),
  payment_method TEXT CHECK (payment_method IN ('bank', 'card', 'crypto', 'paypal', 'trade')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'completed')),
  admin_note TEXT,
  payment_reference TEXT, -- Stripe payment intent ID, PayPal order ID, crypto txhash, etc.
  reviewed_by UUID REFERENCES public.profiles(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── PRICES (admin-controlled overrides) ────────────────────
CREATE TABLE public.price_overrides (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  asset TEXT NOT NULL UNIQUE CHECK (asset IN ('BTC', 'ETH', 'SOL')),
  override_price NUMERIC(18,2),
  is_overridden BOOLEAN DEFAULT FALSE,
  updated_by UUID REFERENCES public.profiles(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── WALLET ADDRESSES (for crypto deposits) ─────────────────
CREATE TABLE public.wallet_addresses (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  asset TEXT NOT NULL CHECK (asset IN ('BTC', 'ETH', 'SOL', 'USDT')),
  address TEXT NOT NULL,
  network TEXT NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── SEED: initial price overrides ──────────────────────────
INSERT INTO public.price_overrides (asset, override_price, is_overridden)
VALUES 
  ('BTC', NULL, FALSE),
  ('ETH', NULL, FALSE),
  ('SOL', NULL, FALSE);

-- ─── SEED: example deposit wallet addresses ─────────────────
INSERT INTO public.wallet_addresses (asset, address, network)
VALUES
  ('BTC', '1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf', 'Bitcoin Mainnet'),
  ('ETH', '0x742d35Cc6634C0532925a3b8D4C9B8e6', 'Ethereum Mainnet'),
  ('SOL', 'So11111111111111111111111111111111111111112', 'Solana Mainnet'),
  ('USDT', '0x742d35Cc6634C0532925a3b8D4C9B8e6', 'ERC-20');

-- ─── ROW LEVEL SECURITY ─────────────────────────────────────
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.price_overrides ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallet_addresses ENABLE ROW LEVEL SECURITY;

-- profiles: users can read/update their own; admins see all
CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles" ON public.profiles
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- transactions: users see own; admins see all
CREATE POLICY "Users can view own transactions" ON public.transactions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own transactions" ON public.transactions
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage all transactions" ON public.transactions
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- prices: everyone can read; only admins can write
CREATE POLICY "Anyone can read prices" ON public.price_overrides
  FOR SELECT USING (TRUE);

CREATE POLICY "Admins can update prices" ON public.price_overrides
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- wallet addresses: everyone can read active ones
CREATE POLICY "Anyone can view active wallet addresses" ON public.wallet_addresses
  FOR SELECT USING (is_active = TRUE);

-- ─── TRIGGER: auto-create profile on signup ─────────────────
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, usd_balance)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    0
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ─── TRIGGER: update updated_at timestamp ────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER transactions_updated_at BEFORE UPDATE ON public.transactions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── FUNCTION: approve deposit (atomic balance update) ───────
CREATE OR REPLACE FUNCTION approve_deposit(tx_id UUID, admin_id UUID)
RETURNS VOID AS $$
DECLARE
  tx public.transactions%ROWTYPE;
BEGIN
  SELECT * INTO tx FROM public.transactions WHERE id = tx_id FOR UPDATE;
  IF tx.status != 'pending' THEN RAISE EXCEPTION 'Transaction is not pending'; END IF;
  IF tx.type != 'deposit' THEN RAISE EXCEPTION 'Not a deposit'; END IF;
  UPDATE public.profiles SET usd_balance = usd_balance + tx.usd_amount WHERE id = tx.user_id;
  UPDATE public.transactions SET status = 'approved', reviewed_by = admin_id, reviewed_at = NOW() WHERE id = tx_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ─── FUNCTION: approve withdrawal (atomic) ───────────────────
CREATE OR REPLACE FUNCTION approve_withdrawal(tx_id UUID, admin_id UUID)
RETURNS VOID AS $$
DECLARE
  tx public.transactions%ROWTYPE;
  usr public.profiles%ROWTYPE;
BEGIN
  SELECT * INTO tx FROM public.transactions WHERE id = tx_id FOR UPDATE;
  SELECT * INTO usr FROM public.profiles WHERE id = tx.user_id FOR UPDATE;
  IF tx.status != 'pending' THEN RAISE EXCEPTION 'Transaction is not pending'; END IF;
  IF tx.type != 'withdrawal' THEN RAISE EXCEPTION 'Not a withdrawal'; END IF;
  IF usr.usd_balance < tx.usd_amount THEN RAISE EXCEPTION 'Insufficient balance'; END IF;
  UPDATE public.profiles SET usd_balance = usd_balance - tx.usd_amount WHERE id = tx.user_id;
  UPDATE public.transactions SET status = 'approved', reviewed_by = admin_id, reviewed_at = NOW() WHERE id = tx_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
